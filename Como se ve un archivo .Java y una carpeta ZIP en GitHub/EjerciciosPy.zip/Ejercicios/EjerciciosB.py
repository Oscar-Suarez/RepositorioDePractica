class Persona:
    def __init__(self, nombre, edad, dni):
        self.nombre = nombre
        self.edad = edad
        self.dni = dni

    @property
    def nombre(self):
        return self._nombre

    @property
    def edad(self):
        return self._edad

    @property
    def dni(self):
        return self._dni

    @nombre.setter
    def nombre(self, nombre):
        self._nombre = nombre

    def validar_dni(self):
        letras = "TRWAGMYFPDXBNJZSQVHLCKE"
        if len(self._dni) != 9:
            print("DNI incorrecto")
            self._dni = ""
        else:
            letra = self._dni[8]
            num = int(self._dni[:8])
            if letra.upper() != letras[num % 23]:
                print("DNI incorrecto")
                self._dni = ""

    @dni.setter
    def dni(self, dni):
        self.validar_dni()

    @edad.setter
    def edad(self, edad):
        if edad < 0:
            print("Edad incorrecta")
            self._edad = 0
        else:
            self._edad = edad

    def mostrar(self):
        return "Nombre:" + self.nombre + " - Edad:" + str(self.edad) + " - DNI:" + self.dni

    def esMayorDeEdad(self):
        return self.edad >= 18


p1 = Persona

p1.dni = "qwe123"
p1.nombre = "Dan"
p1.edad = 22

print(p1.mostrar(Persona), p1.esMayorDeEdad(Persona))
