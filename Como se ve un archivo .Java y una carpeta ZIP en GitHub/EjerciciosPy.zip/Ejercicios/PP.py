class Persona:

    def __init__(self, nombre, edad, dni):
        self._nombre = nombre
        self._edad = edad
        self._dni = dni


p1 = Persona

p1.__init__("Dan", 12, "qwe123")


