nom = input("Introduce tu nombre: "
VDI

